#include <stdio.h>
#include "util.h"

int main()
{
  display("This is a dummy implementation.");
  return 0;
}
