#include <stdio.h>
#include "util.h"

int main()
{
  init();
  display("This is a dummy implementation.");
  return 0;
}
